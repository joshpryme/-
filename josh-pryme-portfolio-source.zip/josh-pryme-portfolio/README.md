# Josh Pryme Portfolio

A responsive personal portfolio with a luxury black-and-gold visual direction.

**Live project:** https://fin-tracker-ebrw.vercel.app/

## Sections
- Introduction
- About
- Areas of focus
- Selected project
- Social links

## Built with
- HTML
- CSS
- JavaScript

## Run the project
Download or clone this repository, then open `index.html` in a browser.

## Customise
Update the text, social profile URLs and project links in `index.html`. Adjust the design in `style.css`.

---
Created for Josh Pryme — Technology · Innovation · Creativity.
